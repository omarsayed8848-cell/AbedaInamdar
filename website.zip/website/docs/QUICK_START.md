# QUICK START GUIDE

## Open the Website

### 🖥️ Quick Method - Double Click
1. Navigate to: `c:\Users\admin\Desktop\Abeda-Inamdar-College\website\`
2. Double-click `index.html`
3. Website opens in your default browser

---

## File Structure

```
website/
├── index.html          ← Main file (double-click to open)
├── styles.css          ← Website styling
├── script.js           ← Interactivity & animations
├── README.md           ← Detailed documentation
├── QUICK_START.md      ← This file
└── assets/
    └── images/         ← Add images here
```

---

## Website Sections

1. **Navigation Bar** (Top)
   - Logo: AIC - Abeda-Inamdar College
   - Links: Home, About, Academics, Faculty, Admissions, Contact
   - Mobile hamburger menu

2. **Home Section**
   - Welcome message
   - "Apply Now" button

3. **About Section**
   - College information
   - Statistics: 2000+ Students, 150+ Faculty, 20+ Programs, 95% Placement Rate

4. **Academics Section**
   - 6 Programs displayed:
     - Bachelor of Science
     - Bachelor of Commerce
     - Bachelor of Arts
     - Computer Science
     - Engineering
     - Master Programs

5. **Faculty Section**
   - 4 Faculty profiles
   - Names, titles, and bios

6. **Admissions Section**
   - Requirements list
   - Application form
   - Form validation

7. **Contact Section**
   - Contact information
   - Office hours
   - Contact form

8. **Footer**
   - Quick links
   - Social media
   - Copyright

---

## Interactive Features

### ✅ Navigation
- Click any menu item to jump to that section
- Menu highlights current section
- Mobile menu collapses/expands

### ✅ Forms
- **Admission Form**: Fill name, email, phone, select program
- **Contact Form**: Send messages to college
- Both validate email and show success/error messages

### ✅ Animations
- Cards fade in as page loads
- Hover effects on all interactive elements
- Smooth scrolling
- Scroll-to-top button appears after scrolling

### ✅ Mobile Responsive
- Works on phones, tablets, and computers
- Automatically adjusts layout based on screen size

---

## How to Customize

### Change Colors
Edit `styles.css` (lines vary):
- Find `#2c3e50` → Change primary color (dark blue)
- Find `#3498db` → Change accent color (bright blue)

### Change Text Content
Edit `index.html`:
- College name: Search for "Abeda-Inamdar College"
- Contact info: Look in Contact section
- Programs: Edit in Academics section

### Add Images
1. Put images in `assets/images/` folder
2. Replace emoji icons with actual images in `index.html`

### Add New Sections
1. Add new `<section id="name">` in `index.html`
2. Add link in navbar
3. Add CSS styling in `styles.css`
4. Add JavaScript in `script.js` if needed

---

## Technical Details

### Built With
- HTML5 (Semantic markup)
- CSS3 (Responsive grid, modern styling)
- Vanilla JavaScript (No libraries needed)

### Browsers Supported
- Chrome ✓
- Firefox ✓
- Safari ✓
- Edge ✓
- Mobile browsers ✓

### Features
- ✓ Fully responsive
- ✓ Mobile hamburger menu
- ✓ Form validation
- ✓ Smooth animations
- ✓ Professional design
- ✓ Easy to customize

---

## Troubleshooting

### Website doesn't open
- Make sure you're opening `index.html`, not a folder
- Try right-clicking → Open with → Choose your browser

### Styling looks wrong
- Verify `styles.css` is in same folder as `index.html`
- Clear browser cache (Ctrl + Shift + Delete)

### Forms not working
- Enable JavaScript in your browser
- Check browser console (F12) for errors

### Mobile menu stuck
- Refresh the page
- Clear browser cache

---

## Next Steps

1. Open the website in your browser
2. Test all forms and interactive features
3. Scroll through to see animations
4. Test on mobile device
5. Customize with your college's information
6. Deploy to a web host

---

**Website is ready to use!** 🎉

For more details, see **README.md**
