# Abeda-Inamdar College Website

A professional, responsive, and user-friendly college website built with HTML, CSS, and JavaScript.

## 📁 Project Structure

```
website/
├── index.html          # Main HTML file with all sections
├── styles.css          # Professional styling with responsive design
├── script.js           # Interactive JavaScript functionality
└── assets/
    └── images/         # Directory for images (optional)
```

## 🎯 Features

### 1. **Professional Design**
- Clean, modern interface with corporate color scheme
- Professional typography and spacing
- Consistent styling across all sections
- Professional layout with clear hierarchy

### 2. **Responsive & Mobile-Friendly**
- Fully responsive design that works on all devices
- Mobile hamburger menu for tablets and phones
- Optimized touch interactions
- Flexible grid layouts

### 3. **Interactive Elements**
- Smooth page scrolling navigation
- Active navigation link highlighting
- Form validation with error messages
- Animated card entrance effects
- Scroll-to-top button
- Mobile menu toggle

### 4. **Key Sections**

#### Home
- Eye-catching hero section
- Call-to-action button for admissions
- Welcome message

#### About
- College overview
- Statistics (Students, Faculty, Programs, Placement Rate)
- Hover animations on stat boxes

#### Academics
- Display of 6 different programs
- Program cards with descriptions
- Professional program icons
- "Learn More" functionality

#### Faculty
- Faculty member profiles
- Professional titles and bios
- Faculty card animations
- Responsive grid layout

#### Admissions
- Application requirements list
- Express Interest form
- Form validation
- Success/error messages

#### Contact
- Contact information
- Office hours
- Contact form with validation
- Map placeholder ready

#### Footer
- Quick links
- Social media links
- Copyright information

## 🚀 How to Use

### Option 1: Open in Browser
1. Locate the `website` folder on your desktop
2. Double-click `index.html` to open it in your default browser

### Option 2: Use a Local Server (Recommended)
1. Open Command Prompt or PowerShell
2. Navigate to the website folder:
   ```
   cd "c:\Users\admin\Desktop\Abeda-Inamdar-College\website"
   ```
3. Start a Python server (if Python is installed):
   ```
   python -m http.server 8000
   ```
   Or Node.js:
   ```
   npx http-server
   ```
4. Open your browser and go to:
   ```
   http://localhost:8000
   ```

### Option 3: Use VS Code Live Server
1. Open the website folder in VS Code
2. Right-click on `index.html`
3. Select "Open with Live Server"

## ✨ Interactive Features

### Navigation
- Sticky navbar that stays at top while scrolling
- Mobile hamburger menu for small screens
- Active link highlighting showing current section
- Smooth scroll animations

### Forms
- **Admission Form**: Collect student application information
  - Name, email, phone, program selection
  - Real-time validation
  - Success message confirmation

- **Contact Form**: General inquiries
  - Name, email, subject, message
  - Email validation
  - Success/error notifications

### Animations
- Cards fade in smoothly as you scroll
- Stat boxes lift on hover
- Program cards have elevation effect on hover
- Scroll-to-top button appears after scrolling
- Smooth transitions throughout

### Responsive Breakpoints
- **Desktop**: Full navigation menu, multi-column layouts
- **Tablet** (768px and below): Hamburger menu, adjusted grid
- **Mobile** (480px and below): Single column layout, optimized fonts

## 🎨 Color Scheme

- **Primary Color**: #2c3e50 (Dark Blue-Gray) - Headers & Navigation
- **Accent Color**: #3498db (Bright Blue) - Links, Buttons, Highlights
- **Background**: #f8f9fa (Light Gray) - Alternate sections
- **Text**: #333/#555/#666 - Various text colors for hierarchy

## 📝 Customization Guide

### Change Colors
Edit `styles.css` and replace color codes:
- `#2c3e50` - Replace with your primary color
- `#3498db` - Replace with your accent color

### Add Images
1. Add image files to `assets/images/` folder
2. Replace emoji icons with real images:
   ```html
   <!-- Instead of: <div class="faculty-image">👨‍🏫</div> -->
   <img src="assets/images/faculty-name.jpg" alt="Faculty Name" class="faculty-image">
   ```

### Update Content
- College name: Search for "Abeda-Inamdar College" in `index.html`
- Contact info: Update in Contact section
- Programs: Modify program descriptions and details
- Faculty: Replace faculty names and bios

### Add New Sections
1. Add new `<section>` in `index.html`
2. Add navigation link in navbar
3. Style in `styles.css`
4. Add interactivity in `script.js` if needed

## ✅ Professional Standards Met

✓ **Not too funky**: Clean, minimalist design
✓ **Professional**: Corporate color scheme, formal layout
✓ **Formal**: Professional typography, clear hierarchy
✓ **User-friendly**: Intuitive navigation, easy to understand
✓ **Interactive**: Forms, animations, hover effects, smooth scrolling

## 🔧 Browser Compatibility

- Chrome (Latest)
- Firefox (Latest)
- Safari (Latest)
- Edge (Latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 📱 Mobile Optimization

- Hamburger menu for mobile navigation
- Touch-friendly button sizes
- Responsive typography
- Optimized image loading
- Efficient animations for mobile devices

## 🚀 Performance Tips

1. Compress images before adding to assets folder
2. Minify CSS and JavaScript for production
3. Use lazy loading for images
4. Enable browser caching

## 📋 Future Enhancement Ideas

- Search functionality
- Student portal login
- Blog/News section
- Event calendar
- Photo gallery
- Virtual campus tour
- Alumni network
- Online fee payment
- Automated email confirmations
- Dark mode toggle

---

**Website Created**: February 2026  
**For**: Abeda-Inamdar College  
**Technologies**: HTML5, CSS3, Vanilla JavaScript

