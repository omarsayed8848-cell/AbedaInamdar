// ============ LOGIN DROPDOWN TOGGLE ============
const loginToggle = document.querySelector('.login-toggle');
const loginDropdownContent = document.querySelector('.login-dropdown-content');

if (loginToggle && loginDropdownContent) {
    loginToggle.addEventListener('click', (e) => {
        e.stopPropagation();
        loginDropdownContent.classList.toggle('active');
        loginToggle.setAttribute('aria-expanded', loginDropdownContent.classList.contains('active'));
    });
    
    // Close dropdown when a link is clicked
    loginDropdownContent.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            loginDropdownContent.classList.remove('active');
            loginToggle.setAttribute('aria-expanded', 'false');
        });
    });
}

// Close dropdown when clicking outside
document.addEventListener('click', (e) => {
    if (loginToggle && loginDropdownContent && !e.target.closest('.login-dropdown')) {
        loginDropdownContent.classList.remove('active');
        if (loginToggle) loginToggle.setAttribute('aria-expanded', 'false');
    }
});

// ============ NAVIGATION MENU TOGGLE ============
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');
const navLinks = document.querySelectorAll('.nav-link');

if (hamburger) {
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });
}

// Close menu when a link is clicked
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        if (hamburger) {
            hamburger.classList.remove('active');
        }
        if (navMenu) {
            navMenu.classList.remove('active');
        }
    });
});

// ============ ACTIVE NAV LINK HIGHLIGHTING ============
window.addEventListener('scroll', () => {
    let current = '';
    
    const sections = document.querySelectorAll('section');
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (pageYOffset >= sectionTop - 200) {
            current = section.getAttribute('id');
        }
    });

    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href').slice(1) === current) {
            link.classList.add('active');
        }
    });
});

// ============ SLIDER FUNCTIONALITY ============
let slideIndex = 1;

function changeSlide(n) {
    showSlide(slideIndex += n);
}

function currentSlide(n) {
    showSlide(slideIndex = n);
}

function showSlide(n) {
    const slides = document.getElementsByClassName('slide');
    const dots = document.getElementsByClassName('dot');
    
    if (n > slides.length) {
        slideIndex = 1;
    }
    if (n < 1) {
        slideIndex = slides.length;
    }
    
    for (let i = 0; i < slides.length; i++) {
        slides[i].classList.remove('fade');
    }
    for (let i = 0; i < dots.length; i++) {
        dots[i].classList.remove('active');
    }
    
    if (slides[slideIndex - 1]) {
        slides[slideIndex - 1].classList.add('fade');
    }
    if (dots[slideIndex - 1]) {
        dots[slideIndex - 1].classList.add('active');
    }
}

// Auto-slide every 5 seconds
setInterval(() => {
    changeSlide(1);
}, 5000);

// Show first slide on load
showSlide(slideIndex);

// ============ TAB SWITCHING ============
function showTab(tabName) {
    const tabContents = document.getElementsByClassName('tab-content');
    const tabButtons = document.getElementsByClassName('tab-button');
    
    for (let i = 0; i < tabContents.length; i++) {
        tabContents[i].classList.remove('active');
    }
    for (let i = 0; i < tabButtons.length; i++) {
        tabButtons[i].classList.remove('active');
    }
    
    const element = document.getElementById(tabName);
    if (element) {
        element.classList.add('active');
    }
    
    event.target.classList.add('active');
}

// ============ ADMISSION FORM HANDLING ============
const admissionForm = document.getElementById('admissionForm');
const formMessage = document.getElementById('formMessage');

if (admissionForm) {
    admissionForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const fullname = document.getElementById('fullname').value.trim();
        const email = document.getElementById('email').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const program = document.getElementById('program').value;
        const message = document.getElementById('message') ? document.getElementById('message').value.trim() : '';

        if (!fullname || !email || !phone || !program) {
            showMessage(formMessage, 'Please fill in all required fields', 'error');
            return;
        }

        if (!isValidEmail(email)) {
            showMessage(formMessage, 'Please enter a valid email address', 'error');
            return;
        }

        if (!isValidPhone(phone)) {
            showMessage(formMessage, 'Please enter a valid phone number', 'error');
            return;
        }

        // Send to backend
        try {
            const res = await fetch('http://localhost:3000/api/admissions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ fullname, email, phone, program, message })
            });
            const data = await res.json();
            if (res.ok && data.ok) {
                showMessage(formMessage, '✓ Thank you! Your application has been submitted. We will contact you soon.', 'success');
                admissionForm.reset();
            } else {
                showMessage(formMessage, 'Submission failed. Please try again later.', 'error');
            }
        } catch (err) {
            console.error(err);
            showMessage(formMessage, 'Network error. Please try again later.', 'error');
        }

        setTimeout(() => {
            formMessage.style.display = 'none';
        }, 5000);
    });
}

// ============ CONTACT FORM HANDLING ============
function handleContactSubmit(event) {
    event.preventDefault();
    
    const contactForm = document.getElementById('contactForm');
    const contactMessage = document.getElementById('contactMessage');
    
    const name = document.getElementById('cname')?.value?.trim() || '';
    const email = document.getElementById('cemail')?.value?.trim() || '';
    const phone = document.getElementById('cphone')?.value?.trim() || '';
    const subject = document.getElementById('subject')?.value?.trim() || '';
    const message = document.getElementById('cmessage')?.value?.trim() || '';

    console.log('Contact Form Submitted:', { name, email, phone, subject, message });

    // Validation
    if (!name || !email || !subject || !message) {
        console.log('Validation failed - Empty field(s)');
        showMessage(contactMessage, 'Please fill in all fields', 'error');
        return false;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        console.log('Invalid email format');
        showMessage(contactMessage, 'Please enter a valid email address', 'error');
        return false;
    }

    // Submit to backend
    const formData = {
        name: name,
        email: email,
        phone: phone || null,
        subject: subject,
        message: message
    };

    // Show loading message
    showMessage(contactMessage, 'Sending your message...', 'info');

    fetch('http://localhost:3000/api/contact', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.ok) {
            console.log('Contact form submitted successfully');
            showMessage(contactMessage, '✓ Thank you for your message! We will get back to you soon.', 'success');
            contactForm.reset();
            
            setTimeout(() => {
                if (contactMessage) contactMessage.style.display = 'none';
            }, 5000);
        } else {
            throw new Error(data.error || 'Failed to submit form');
        }
    })
    .catch(error => {
        console.error('Error submitting contact form:', error);
        showMessage(contactMessage, '✗ Failed to send message. Please try again later or contact us directly.', 'error');
    });

    return false;
}

// ============ LEGACY CONTACT FORM HANDLING ============
const contactForm = document.getElementById('contactForm');
const contactMessage = document.getElementById('contactMessage');

// ============ NEWSLETTER FORM ============
const newsletterForm = document.getElementById('newsletterForm');

if (newsletterForm) {
    newsletterForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const input = newsletterForm.querySelector('input[type="email"]');
        const email = input ? input.value.trim() : '';

        if (!isValidEmail(email)) {
            alert('Please enter a valid email address');
            return;
        }

        try {
            const res = await fetch('http://localhost:3000/api/newsletter', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email })
            });
            const data = await res.json();
            if (res.ok && data.ok) {
                alert('✓ Thank you for subscribing!');
                newsletterForm.reset();
            } else {
                alert('Subscription failed. Please try again later.');
            }
        } catch (err) {
            console.error(err);
            alert('Network error. Please try again later.');
        }
    });
}

// ============ FORM VALIDATION HELPERS ============
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isValidPhone(phone) {
    const phoneRegex = /^[0-9\-\+\(\)\s]{10,}$/;
    return phoneRegex.test(phone);
}

function showMessage(element, message, type) {
    element.textContent = message;
    element.className = `form-message ${type}`;
    element.style.display = 'block';
}

// ============ CHATBOT FUNCTIONALITY ============
const chatbotToggle = document.getElementById('chatbotToggle');
const chatbotWindow = document.getElementById('chatbotWindow');
const closeChatbot = document.getElementById('closeChatbot');
const chatInput = document.getElementById('chatInput');
const chatMessages = document.getElementById('chatbotMessages');

if (chatbotToggle) {
    chatbotToggle.addEventListener('click', () => {
        chatbotWindow.classList.toggle('active');
    });
}

if (closeChatbot) {
    closeChatbot.addEventListener('click', () => {
        chatbotWindow.classList.remove('active');
    });
}

// Chat responses database - Comprehensive Q&A for college
const chatResponses = {
    'admission|apply|enroll|registration': 'We are currently accepting applications for all undergraduate and postgraduate programs. You can apply online through our website or visit our admissions office (2390-B, K.B. Hidayatullah Road, Pune 411001) with required documents.',
    'program|course|degree|bachelor|master': 'We offer: B.A., B.Com., B.Sc., B.Sc. Computer Applications, B.Sc. Computer Science, M.A., M.Com., and M.Sc. programs. Which program interests you?',
    'contact|call|email|phone|address': 'Phone: +91-20-26457577 | Email: prin-aisc@azamcampus.org | Address: 2390-B, K.B. Hidayatullah Road, Azam Campus, Camp, Pune 411001.',
    'hour|timing|office|open|close|when': 'Office Hours: Monday to Friday, 10:00 AM - 5:00 PM. Closed on Saturdays and Sundays. We\'re available during these hours to help you!',
    'placement|job|career|recruit': 'Our college has a 95% placement rate with placements from leading companies. We provide career counseling and placement assistance to all students.',
    'infrastructure|campus|facility|lab|classroom': 'We have state-of-the-art infrastructure including smart classrooms, well-equipped laboratories, high-speed computer labs, modern library, sports complex, and recreational facilities.',
    'library|book|resource|digital|database': 'Our library has 50,000+ books, e-journals, online databases, and provides 24/7 digital access to students. It\'s a comprehensive learning hub.',
    'fee|scholarship|cost|financial|aid': 'For detailed fee information and scholarship opportunities, please contact our admissions office. We offer various financial aid and scholarship programs.',
    'nss|sports|activity|club|event|culture': 'We conduct regular cultural events, sports tournaments, NSS activities, and club meetings. Our students participate in debates, exhibitions, seminars, and sports competitions.',
    'faculty|teacher|staff|professor': 'Our college has a highly efficient and dedicated teaching staff committed to academic excellence and holistic student development.',
    'hello|hi|hey|greetings': 'Hello! Welcome to Abeda-Inamdar College. I\'m here to help! Ask me anything about admissions, programs, faculty, campus life, or contact information.',
    'help|what|how|can you': 'I can help you with information about: admissions & applications, programs & courses, campus facilities, faculty, fees & scholarships, placement, activities, and much more! What would you like to know?',
    'mission|vision|philosophy|goal|objective': 'Our mission is "Read to Lead" - to empower students through quality education combined with sports and extracurricular activities. We believe in developing talented, young, dynamic professionals.',
    'autonomous|naac|nirf|accredit': 'We are an autonomous institution with Grade A NAAC accreditation and affiliated to Savitribai Phule Pune University. We maintain high academic standards.',
    'research|project|innovation|study': 'We promote research and innovation among students and faculty. Our college encourages research projects and provides facilities for academic exploration.',
    'thanks|thank you|appreciate': 'You\'re welcome! Feel free to ask if you have more questions. We\'re here to help!',
    'bye|goodbye|exit|quit': 'Thank you for chatting with us! Feel free to reach out anytime you have questions. Have a great day!'
};

function sendChatMessage(predefinedMessage = null) {
    const message = predefinedMessage || chatInput.value.trim();
    
    if (!message) return;
    
    // Add user message to chat
    const userMessageDiv = document.createElement('div');
    userMessageDiv.className = 'user-message';
    userMessageDiv.innerHTML = `<p>${escapeHtml(message)}</p>`;
    chatMessages.appendChild(userMessageDiv);
    
    chatInput.value = '';
    
    // Clear suggestions when user sends a message
    const suggestionsDiv = document.querySelector('.chatbot-suggestions');
    if (suggestionsDiv) {
        suggestionsDiv.style.display = 'none';
    }
    
    // Auto-scroll to bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    // Get bot response
    setTimeout(() => {
        const response = getChatbotResponse(message);
        const botMessageDiv = document.createElement('div');
        botMessageDiv.className = 'bot-message';
        botMessageDiv.innerHTML = `<p>${response}</p>`;
        chatMessages.appendChild(botMessageDiv);
        
        // Auto-scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }, 500);
}

function getChatbotResponse(userMessage) {
    const message = userMessage.toLowerCase().trim();
    
    // Check for keyword patterns in the message
    for (const [keywords, response] of Object.entries(chatResponses)) {
        const keywordArray = keywords.split('|');
        for (const keyword of keywordArray) {
            if (message.includes(keyword.trim())) {
                return response;
            }
        }
    }
    
    // Intelligent fallback for unmatched questions
    return generateIntelligentResponse(message);
}

function generateIntelligentResponse(userMessage) {
    // Analyze question patterns and provide contextual responses
    if (userMessage.includes('?') || userMessage.includes('what') || userMessage.includes('when') || 
        userMessage.includes('where') || userMessage.includes('how') || userMessage.includes('why')) {
        return 'That\'s a great question! For detailed information, please contact our admissions office at +91-20-26457577 or email prin-aisc@azamcampus.org. You can also visit our website or campus in person.';
    }
    
    // General acknowledgment for statements
    if (userMessage.length > 0) {
        return 'Thank you for your message! We appreciate your interest in Abeda-Inamdar College. If you have a specific question, feel free to ask, or contact our admissions team at +91-20-26457577 for assistance.';
    }
    
    return 'I\'m here to help! Ask me anything about our college - admissions, programs, campus facilities, faculty, or any other information you need.';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Allow sending message with Enter key
if (chatInput) {
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendChatMessage();
        }
    });
}

// ============ SMOOTH SCROLL BEHAVIOR ============
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href !== '#' && document.querySelector(href)) {
            e.preventDefault();
            document.querySelector(href).scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// ============ PAGE LOAD ANIMATIONS ============
window.addEventListener('load', () => {
    // Fade in animations
    const elements = document.querySelectorAll('.program-card, .library-card, .news-card, .stat-item');
    elements.forEach((el, index) => {
        setTimeout(() => {
            el.style.animation = 'fadeInUp 0.6s ease forwards';
        }, index * 100);
    });
});

// ============ ADD FADE-IN ANIMATION ============
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
`;
document.head.appendChild(style);

// ============ SCROLL TO TOP BUTTON ============
let scrollTopButton = document.createElement('button');
scrollTopButton.innerHTML = '↑';
scrollTopButton.className = 'scroll-to-top';
scrollTopButton.id = 'scrollToTop';
document.body.appendChild(scrollTopButton);

const scrollTopStyle = document.createElement('style');
scrollTopStyle.textContent = `
    .scroll-to-top {
        position: fixed;
        bottom: 30px;
        right: 30px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 50%;
        width: 50px;
        height: 50px;
        font-size: 24px;
        cursor: pointer;
        display: none;
        z-index: 98;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
    }
    
    .scroll-to-top.show {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .scroll-to-top:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.5);
    }
`;
document.head.appendChild(scrollTopStyle);

const scrollToTopButton = document.getElementById('scrollToTop');

window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
        scrollToTopButton.classList.add('show');
    } else {
        scrollToTopButton.classList.remove('show');
    }
});

scrollToTopButton.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// ============ LEARN MORE BUTTONS ============
const learnMoreButtons = document.querySelectorAll('.card-btn');

learnMoreButtons.forEach(button => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        const card = button.closest('.program-card');
        const programName = card.querySelector('h3').textContent;
        
        const message = `You're interested in ${programName}. For more information, please fill out the admission form or contact our admissions office.`;
        sendChatMessage(message);
        
        // Open chatbot if closed
        const chatbot = document.getElementById('chatbotWindow');
        if (chatbot && !chatbot.classList.contains('active')) {
            chatbot.classList.add('active');
        }
    });
});

// ============ KEYBOARD NAVIGATION ============
document.addEventListener('keydown', (e) => {
    // Close chatbot with Escape key
    if (e.key === 'Escape') {
        const chatbot = document.getElementById('chatbotWindow');
        if (chatbot) {
            chatbot.classList.remove('active');
        }
    }
});

console.log('✓ Website loaded successfully! Welcome to Abeda-Inamdar College');
