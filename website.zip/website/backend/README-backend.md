Backend setup for Abeda-Inamdar College website

1. Install Node.js (v16+ recommended) and MySQL server.
2. Create the database and tables:

   - Open MySQL client and run `backend/schema.sql` or use:

```sql
-- from MySQL client
SOURCE path/to/website/backend/schema.sql;
```

3. Copy `.env.example` to `.env` and update credentials.
4. Install dependencies and start server:

```bash
cd website/backend
npm install
npm run start
```

5. API endpoints:
- POST /api/admissions { fullname, email, phone, program, message }
- POST /api/contact { name, email, phone, subject, message }
- POST /api/newsletter { email }

The frontend should POST JSON to `http://localhost:3000/api/...`.
