const express = require('express');
const router = express.Router();
const pool = require('../db');

// POST /api/admissions
router.post('/admissions', async (req, res) => {
  const { fullname, email, phone, program, message } = req.body;
  if (!fullname || !email || !phone || !program) {
    return res.status(400).json({ ok: false, error: 'Missing required fields' });
  }

  try {
    const sql = `INSERT INTO admissions (fullname, email, phone, program, message) VALUES (?, ?, ?, ?, ?)`;
    const [result] = await pool.execute(sql, [fullname, email, phone, program, message || null]);
    res.json({ ok: true, id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: 'Database error' });
  }
});

// POST /api/contact
router.post('/contact', async (req, res) => {
  const { name, email, phone, subject, message } = req.body;
  if (!name || !email || !subject || !message) {
    return res.status(400).json({ ok: false, error: 'Missing required fields' });
  }

  try {
    const sql = `INSERT INTO contacts (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)`;
    const [result] = await pool.execute(sql, [name, email, phone || null, subject, message]);
    res.json({ ok: true, id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: 'Database error' });
  }
});

// POST /api/newsletter
router.post('/newsletter', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ ok: false, error: 'Email is required' });

  try {
    const sql = `INSERT INTO newsletter (email) VALUES (?)`;
    const [result] = await pool.execute(sql, [email]);
    res.json({ ok: true, id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: 'Database error' });
  }
});

module.exports = router;
